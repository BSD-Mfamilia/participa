<?php

$config['access_token']="bef9918d862931a109a755b7e6e43f1c8fe5711e966c4fdc05e18a6947159797";
$config['baseApiUrl'] = 'https://masmadrid.nationbuilder.com';
$config['tagOK']="BienvenidaOKMasiva";
$config['DEBUG']=5;
$config['LOG2FILE']=true;
$config['LOGFILE']="./confirmation.log";
$config['LOG2SCR']=false;
//$config['']=;
